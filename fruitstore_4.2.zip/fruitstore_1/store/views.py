from django.shortcuts import render

# Create your views here.
def store(request):
    context = {}
    return render(request, 'store/index_shop.html', context)

def cart(request):
    context = {}
    return render(request, 'store/cart.html', context)

def contact(request):
    context = {}
    return render(request, 'store/contact.html', context)